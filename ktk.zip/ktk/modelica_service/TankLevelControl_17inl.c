/* Inline equation file is empty */
#include "TankLevelControl_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int TankLevelControl_symbolicInlineSystem(DATA *data, threadData_t *threadData){
  return -1;
}
#ifdef __cplusplus
}
#endif
