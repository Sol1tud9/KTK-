/* Events: Sample, Zero Crossings, Relations, Discrete Changes */
#include "TankControlSystem_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* Initializes the raw time events of the simulation using the now
   calcualted parameters. */
void TankControlSystem_function_initSample(DATA *data, threadData_t *threadData)
{
  long i=0;
}

const char *TankControlSystem_zeroCrossingDescription(int i, int **out_EquationIndexes)
{
  static const char *res[] = {"heaterPower < heaterPowerMax and heaterPower > 0.0"};
  static const int occurEqs0[] = {1,24};
  static const int *occurEqs[] = {occurEqs0};
  *out_EquationIndexes = (int*) occurEqs[i];
  return res[i];
}

/* forwarded equations */
extern void TankControlSystem_eqFunction_14(DATA* data, threadData_t *threadData);
extern void TankControlSystem_eqFunction_21(DATA* data, threadData_t *threadData);
extern void TankControlSystem_eqFunction_22(DATA* data, threadData_t *threadData);
extern void TankControlSystem_eqFunction_24(DATA* data, threadData_t *threadData);

int TankControlSystem_function_ZeroCrossingsEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->callStatistics.functionZeroCrossingsEquations++;

  TankControlSystem_eqFunction_14(data, threadData);

  TankControlSystem_eqFunction_21(data, threadData);

  TankControlSystem_eqFunction_22(data, threadData);

  TankControlSystem_eqFunction_24(data, threadData);
  
  TRACE_POP
  return 0;
}

int TankControlSystem_function_ZeroCrossings(DATA *data, threadData_t *threadData, double *gout)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;

  modelica_boolean tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_boolean tmp3;
  modelica_real tmp4;
  modelica_real tmp5;

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ZC);
#endif
  data->simulationInfo->callStatistics.functionZeroCrossings++;

  tmp1 = 1.0;
  tmp2 = fabs((data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */));
  tmp0 = LessZC((data->localData[0]->realVars[7] /* heaterPower variable */), (data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */), tmp1, tmp2, data->simulationInfo->storedRelations[0]);
  tmp4 = 1.0;
  tmp5 = 0.0;
  tmp3 = GreaterZC((data->localData[0]->realVars[7] /* heaterPower variable */), 0.0, tmp4, tmp5, data->simulationInfo->storedRelations[1]);
  gout[0] = ((tmp0 && tmp3)) ? 1 : -1;

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ZC);
#endif

  TRACE_POP
  return 0;
}

const char *TankControlSystem_relationDescription(int i)
{
  const char *res[] = {"heaterPower < heaterPowerMax",
  "heaterPower > 0.0"};
  return res[i];
}

int TankControlSystem_function_updateRelations(DATA *data, threadData_t *threadData, int evalforZeroCross)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;

  modelica_boolean tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_boolean tmp9;
  modelica_real tmp10;
  modelica_real tmp11;
  
  if(evalforZeroCross) {
    tmp7 = 1.0;
    tmp8 = fabs((data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */));
    tmp6 = LessZC((data->localData[0]->realVars[7] /* heaterPower variable */), (data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */), tmp7, tmp8, data->simulationInfo->storedRelations[0]);
    data->simulationInfo->relations[0] = tmp6;

    tmp10 = 1.0;
    tmp11 = 0.0;
    tmp9 = GreaterZC((data->localData[0]->realVars[7] /* heaterPower variable */), 0.0, tmp10, tmp11, data->simulationInfo->storedRelations[1]);
    data->simulationInfo->relations[1] = tmp9;
  } else {
    data->simulationInfo->relations[0] = ((data->localData[0]->realVars[7] /* heaterPower variable */) < (data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */));

    data->simulationInfo->relations[1] = ((data->localData[0]->realVars[7] /* heaterPower variable */) > 0.0);
  }
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

