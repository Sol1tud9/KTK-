/* Initialization */
#include "TankControlSystem_model.h"
#include "TankControlSystem_11mix.h"
#include "TankControlSystem_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void TankControlSystem_functionInitialEquations_0(DATA *data, threadData_t *threadData);

/*
equation index: 1
type: SIMPLE_ASSIGN
integralError = 0.0
*/
void TankControlSystem_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  (data->localData[0]->realVars[1] /* integralError STATE(1) */) = 0.0;
  TRACE_POP
}

/*
equation index: 2
type: SIMPLE_ASSIGN
temperature = initialTemperature
*/
void TankControlSystem_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  (data->localData[0]->realVars[8] /* temperature DUMMY_STATE */) = (data->simulationInfo->realParameter[8] /* initialTemperature PARAM */);
  TRACE_POP
}

/*
equation index: 3
type: SIMPLE_ASSIGN
error = setpointTemperature - temperature
*/
void TankControlSystem_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  (data->localData[0]->realVars[0] /* error STATE(1,derivativeError) */) = (data->simulationInfo->realParameter[9] /* setpointTemperature PARAM */) - (data->localData[0]->realVars[8] /* temperature DUMMY_STATE */);
  TRACE_POP
}

void TankControlSystem_eqFunction_4(DATA*, threadData_t*);
void TankControlSystem_eqFunction_5(DATA*, threadData_t*);
void TankControlSystem_eqFunction_6(DATA*, threadData_t*);
/*
equation index: 11
indexNonlinear: 0
type: NONLINEAR

vars: {derivativeError}
eqns: {4, 5, 6}
*/
void TankControlSystem_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 11 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[0].nlsxOld[0] = (data->localData[0]->realVars[6] /* derivativeError variable */);
  retValue = solve_nonlinear_system(data, threadData, 0);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,11};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving non-linear system 11 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[6] /* derivativeError variable */) = data->simulationInfo->nonlinearSystemData[0].nlsx[0];
  TRACE_POP
}
extern void TankControlSystem_eqFunction_22(DATA *data, threadData_t *threadData);

extern void TankControlSystem_eqFunction_24(DATA *data, threadData_t *threadData);

OMC_DISABLE_OPT
void TankControlSystem_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  TankControlSystem_eqFunction_1(data, threadData);
  TankControlSystem_eqFunction_2(data, threadData);
  TankControlSystem_eqFunction_3(data, threadData);
  TankControlSystem_eqFunction_11(data, threadData);
  TankControlSystem_eqFunction_22(data, threadData);
  TankControlSystem_eqFunction_24(data, threadData);
  TRACE_POP
}

int TankControlSystem_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  TankControlSystem_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}

/* No TankControlSystem_functionInitialEquations_lambda0 function */

int TankControlSystem_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

