/* Initial State Set */
#include "TankLevelControl_model.h"
#include "TankLevelControl_11mix.h"
#include "TankLevelControl_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void TankLevelControl_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

