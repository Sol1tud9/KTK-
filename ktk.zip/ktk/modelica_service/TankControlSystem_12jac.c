/* Jacobians 8 */
#include "TankControlSystem_model.h"
#include "TankControlSystem_12jac.h"
#include "simulation/jacobian_util.h"
#include "util/omc_file.h"
/* constant equations */
/* dynamic equations */

/*
equation index: 7
type: SIMPLE_ASSIGN
$cse1 = max(Kp * error + Ki * integralError + Kd * derivativeError, 0.0)
*/
void TankControlSystem_eqFunction_7(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,7};
  jacobian->tmpVars[0] /* $cse1 JACOBIAN_TMP_VAR */ = fmax(((data->simulationInfo->realParameter[2] /* Kp PARAM */)) * ((data->localData[0]->realVars[0] /* error STATE(1,derivativeError) */)) + ((data->simulationInfo->realParameter[1] /* Ki PARAM */)) * ((data->localData[0]->realVars[1] /* integralError STATE(1) */)) + ((data->simulationInfo->realParameter[0] /* Kd PARAM */)) * ((data->localData[0]->realVars[6] /* derivativeError variable */)),0.0);
  TRACE_POP
}

/*
equation index: 8
type: SIMPLE_ASSIGN
heaterPower.$pDERNLSJac0.dummyVarNLSJac0 = if noEvent($cse1 < heaterPowerMax) then if noEvent(Kp * error + Ki * integralError + Kd * derivativeError > 0.0) then Kd * derivativeError.SeedNLSJac0 else 0.0 else 0.0
*/
void TankControlSystem_eqFunction_8(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,8};
  modelica_boolean tmp0;
  modelica_boolean tmp1;
  modelica_boolean tmp2;
  modelica_real tmp3;
  tmp0 = Less(jacobian->tmpVars[0] /* $cse1 JACOBIAN_TMP_VAR */,(data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */));
  tmp2 = (modelica_boolean)tmp0;
  if(tmp2)
  {
    tmp1 = Greater(((data->simulationInfo->realParameter[2] /* Kp PARAM */)) * ((data->localData[0]->realVars[0] /* error STATE(1,derivativeError) */)) + ((data->simulationInfo->realParameter[1] /* Ki PARAM */)) * ((data->localData[0]->realVars[1] /* integralError STATE(1) */)) + ((data->simulationInfo->realParameter[0] /* Kd PARAM */)) * ((data->localData[0]->realVars[6] /* derivativeError variable */)),0.0);
    tmp3 = (tmp1?((data->simulationInfo->realParameter[0] /* Kd PARAM */)) * (jacobian->seedVars[0] /* derivativeError.SeedNLSJac0 SEED_VAR */):0.0);
  }
  else
  {
    tmp3 = 0.0;
  }
  jacobian->tmpVars[1] /* heaterPower.$pDERNLSJac0.dummyVarNLSJac0 JACOBIAN_TMP_VAR */ = tmp3;
  TRACE_POP
}

/*
equation index: 9
type: SIMPLE_ASSIGN
$DER.temperature.$pDERNLSJac0.dummyVarNLSJac0 = heaterPower.$pDERNLSJac0.dummyVarNLSJac0 * tankVolume * density * heatCapacity / (tankVolume * density * heatCapacity) ^ 2.0
*/
void TankControlSystem_eqFunction_9(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,9};
  modelica_real tmp4;
  tmp4 = ((data->simulationInfo->realParameter[10] /* tankVolume PARAM */)) * (((data->simulationInfo->realParameter[4] /* density PARAM */)) * ((data->simulationInfo->realParameter[5] /* heatCapacity PARAM */)));
  jacobian->tmpVars[2] /* der(temperature.$pDERNLSJac0.dummyVarNLSJac0) JACOBIAN_TMP_VAR */ = (jacobian->tmpVars[1] /* heaterPower.$pDERNLSJac0.dummyVarNLSJac0 JACOBIAN_TMP_VAR */) * (((data->simulationInfo->realParameter[10] /* tankVolume PARAM */)) * (((data->simulationInfo->realParameter[4] /* density PARAM */)) * (DIVISION((data->simulationInfo->realParameter[5] /* heatCapacity PARAM */),(tmp4 * tmp4),"(tankVolume * density * heatCapacity) ^ 2.0"))));
  TRACE_POP
}

/*
equation index: 10
type: SIMPLE_ASSIGN
$res_NLSJac0_1.$pDERNLSJac0.dummyVarNLSJac0 = (-$DER.temperature.$pDERNLSJac0.dummyVarNLSJac0) - derivativeError.SeedNLSJac0
*/
void TankControlSystem_eqFunction_10(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,10};
  jacobian->resultVars[0] /* $res_NLSJac0_1.$pDERNLSJac0.dummyVarNLSJac0 JACOBIAN_VAR */ = (-jacobian->tmpVars[2] /* der(temperature.$pDERNLSJac0.dummyVarNLSJac0) JACOBIAN_TMP_VAR */) - jacobian->seedVars[0] /* derivativeError.SeedNLSJac0 SEED_VAR */;
  TRACE_POP
}

OMC_DISABLE_OPT
int TankControlSystem_functionJacNLSJac0_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TankControlSystem_INDEX_JAC_NLSJac0;
  
  TRACE_POP
  return 0;
}

int TankControlSystem_functionJacNLSJac0_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TankControlSystem_INDEX_JAC_NLSJac0;
  TankControlSystem_eqFunction_7(data, threadData, jacobian, parentJacobian);
  TankControlSystem_eqFunction_8(data, threadData, jacobian, parentJacobian);
  TankControlSystem_eqFunction_9(data, threadData, jacobian, parentJacobian);
  TankControlSystem_eqFunction_10(data, threadData, jacobian, parentJacobian);
  TRACE_POP
  return 0;
}
/* constant equations */
/* dynamic equations */

/*
equation index: 18
type: SIMPLE_ASSIGN
$cse2.$pDERNLSJac1.dummyVarNLSJac1 = if noEvent(Kp * error + Ki * integralError + Kd * derivativeError > 0.0) then Kd * derivativeError.SeedNLSJac1 else 0.0
*/
void TankControlSystem_eqFunction_18(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,18};
  modelica_boolean tmp5;
  tmp5 = Greater(((data->simulationInfo->realParameter[2] /* Kp PARAM */)) * ((data->localData[0]->realVars[0] /* error STATE(1,derivativeError) */)) + ((data->simulationInfo->realParameter[1] /* Ki PARAM */)) * ((data->localData[0]->realVars[1] /* integralError STATE(1) */)) + ((data->simulationInfo->realParameter[0] /* Kd PARAM */)) * ((data->localData[0]->realVars[6] /* derivativeError variable */)),0.0);
  jacobian->tmpVars[0] /* $cse2.$pDERNLSJac1.dummyVarNLSJac1 JACOBIAN_TMP_VAR */ = (tmp5?((data->simulationInfo->realParameter[0] /* Kd PARAM */)) * (jacobian->seedVars[0] /* derivativeError.SeedNLSJac1 SEED_VAR */):0.0);
  TRACE_POP
}

/*
equation index: 19
type: SIMPLE_ASSIGN
heaterPower.$pDERNLSJac1.dummyVarNLSJac1 = if noEvent($cse2 < heaterPowerMax) then $cse2.$pDERNLSJac1.dummyVarNLSJac1 else 0.0
*/
void TankControlSystem_eqFunction_19(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,19};
  modelica_boolean tmp6;
  tmp6 = Less((data->localData[0]->realVars[5] /* $cse2 variable */),(data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */));
  jacobian->tmpVars[1] /* heaterPower.$pDERNLSJac1.dummyVarNLSJac1 JACOBIAN_TMP_VAR */ = (tmp6?jacobian->tmpVars[0] /* $cse2.$pDERNLSJac1.dummyVarNLSJac1 JACOBIAN_TMP_VAR */:0.0);
  TRACE_POP
}

/*
equation index: 20
type: SIMPLE_ASSIGN
$res_NLSJac1_1.$pDERNLSJac1.dummyVarNLSJac1 = heaterPower.$pDERNLSJac1.dummyVarNLSJac1 + derivativeError.SeedNLSJac1 * heatCapacity * density * tankVolume
*/
void TankControlSystem_eqFunction_20(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,20};
  jacobian->resultVars[0] /* $res_NLSJac1_1.$pDERNLSJac1.dummyVarNLSJac1 JACOBIAN_VAR */ = jacobian->tmpVars[1] /* heaterPower.$pDERNLSJac1.dummyVarNLSJac1 JACOBIAN_TMP_VAR */ + (jacobian->seedVars[0] /* derivativeError.SeedNLSJac1 SEED_VAR */) * (((data->simulationInfo->realParameter[5] /* heatCapacity PARAM */)) * (((data->simulationInfo->realParameter[4] /* density PARAM */)) * ((data->simulationInfo->realParameter[10] /* tankVolume PARAM */))));
  TRACE_POP
}

OMC_DISABLE_OPT
int TankControlSystem_functionJacNLSJac1_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TankControlSystem_INDEX_JAC_NLSJac1;
  
  TRACE_POP
  return 0;
}

int TankControlSystem_functionJacNLSJac1_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TankControlSystem_INDEX_JAC_NLSJac1;
  TankControlSystem_eqFunction_18(data, threadData, jacobian, parentJacobian);
  TankControlSystem_eqFunction_19(data, threadData, jacobian, parentJacobian);
  TankControlSystem_eqFunction_20(data, threadData, jacobian, parentJacobian);
  TRACE_POP
  return 0;
}
int TankControlSystem_functionJacH_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int TankControlSystem_functionJacF_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int TankControlSystem_functionJacD_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int TankControlSystem_functionJacC_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int TankControlSystem_functionJacB_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
/* constant equations */
/* dynamic equations */

OMC_DISABLE_OPT
int TankControlSystem_functionJacA_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TankControlSystem_INDEX_JAC_A;
  
  TRACE_POP
  return 0;
}

int TankControlSystem_functionJacA_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TankControlSystem_INDEX_JAC_A;
  TRACE_POP
  return 0;
}

OMC_DISABLE_OPT
int TankControlSystem_initialAnalyticJacobianNLSJac0(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TankControlSystem_JacNLSJac0.bin");
  
  initAnalyticJacobian(jacobian, 1, 1, 4, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(1, 1, 1);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 1+1, pFile, FALSE);
  if (count != 1+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %zu", 1+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 1, pFile, FALSE);
  if (count != 1) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %zu", 1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1, 1);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}
OMC_DISABLE_OPT
int TankControlSystem_initialAnalyticJacobianNLSJac1(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TankControlSystem_JacNLSJac1.bin");
  
  initAnalyticJacobian(jacobian, 1, 1, 3, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(1, 1, 1);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 1+1, pFile, FALSE);
  if (count != 1+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %zu", 1+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 1, pFile, FALSE);
  if (count != 1) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %zu", 1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1, 1);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}
int TankControlSystem_initialAnalyticJacobianH(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int TankControlSystem_initialAnalyticJacobianF(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int TankControlSystem_initialAnalyticJacobianD(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int TankControlSystem_initialAnalyticJacobianC(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int TankControlSystem_initialAnalyticJacobianB(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
OMC_DISABLE_OPT
int TankControlSystem_initialAnalyticJacobianA(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TankControlSystem_JacA.bin");
  
  initAnalyticJacobian(jacobian, 2, 2, 0, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(2, 4, 2);
  jacobian->availability = JACOBIAN_ONLY_SPARSITY;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 2+1, pFile, FALSE);
  if (count != 2+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %zu", 2+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 4, pFile, FALSE);
  if (count != 4) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %zu", 4, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1, 2);
  /* color 2 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 2, 1, 2);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}



