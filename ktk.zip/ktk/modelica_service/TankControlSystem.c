/* Main Simulation File */

#if defined(__cplusplus)
extern "C" {
#endif

#include "TankControlSystem_model.h"
#include "simulation/solver/events.h"

/* FIXME these defines are ugly and hard to read, why not use direct function pointers instead? */
#define prefixedName_performSimulation TankControlSystem_performSimulation
#define prefixedName_updateContinuousSystem TankControlSystem_updateContinuousSystem
#include <simulation/solver/perform_simulation.c.inc>

#define prefixedName_performQSSSimulation TankControlSystem_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c.inc>


/* dummy VARINFO and FILEINFO */
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;

int TankControlSystem_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TankControlSystem_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TankControlSystem_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TankControlSystem_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TankControlSystem_data_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  TRACE_POP
  return 0;
}

int TankControlSystem_dataReconciliationInputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TankControlSystem_dataReconciliationUnmeasuredVariables(DATA *data, char ** names)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TankControlSystem_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TankControlSystem_setc_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TankControlSystem_setb_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/*
equation index: 14
type: SIMPLE_ASSIGN
temperature = setpointTemperature - error
*/
void TankControlSystem_eqFunction_14(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,14};
  (data->localData[0]->realVars[8] /* temperature DUMMY_STATE */) = (data->simulationInfo->realParameter[9] /* setpointTemperature PARAM */) - (data->localData[0]->realVars[0] /* error STATE(1,derivativeError) */);
  TRACE_POP
}
void TankControlSystem_eqFunction_15(DATA*, threadData_t*);
void TankControlSystem_eqFunction_16(DATA*, threadData_t*);
void TankControlSystem_eqFunction_17(DATA*, threadData_t*);
/*
equation index: 21
indexNonlinear: 1
type: NONLINEAR

vars: {derivativeError}
eqns: {15, 16, 17}
*/
void TankControlSystem_eqFunction_21(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,21};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 21 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[1].nlsxOld[0] = (data->localData[0]->realVars[6] /* derivativeError variable */);
  retValue = solve_nonlinear_system(data, threadData, 1);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,21};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving non-linear system 21 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[6] /* derivativeError variable */) = data->simulationInfo->nonlinearSystemData[1].nlsx[0];
  TRACE_POP
}
/*
equation index: 22
type: SIMPLE_ASSIGN
$DER.error = derivativeError
*/
void TankControlSystem_eqFunction_22(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,22};
  (data->localData[0]->realVars[2] /* der(error) STATE_DER */) = (data->localData[0]->realVars[6] /* derivativeError variable */);
  TRACE_POP
}
/*
equation index: 23
type: SIMPLE_ASSIGN
$DER.temperature = -derivativeError
*/
void TankControlSystem_eqFunction_23(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,23};
  (data->localData[0]->realVars[4] /* der(temperature) DUMMY_DER */) = (-(data->localData[0]->realVars[6] /* derivativeError variable */));
  TRACE_POP
}
/*
equation index: 24
type: SIMPLE_ASSIGN
$DER.integralError = if heaterPower < heaterPowerMax and heaterPower > 0.0 then error else 0.0
*/
void TankControlSystem_eqFunction_24(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,24};
  modelica_boolean tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_boolean tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  tmp1 = 1.0;
  tmp2 = fabs((data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */));
  relationhysteresis(data, &tmp0, (data->localData[0]->realVars[7] /* heaterPower variable */), (data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */), tmp1, tmp2, 0, Less, LessZC);
  tmp4 = 1.0;
  tmp5 = 0.0;
  relationhysteresis(data, &tmp3, (data->localData[0]->realVars[7] /* heaterPower variable */), 0.0, tmp4, tmp5, 1, Greater, GreaterZC);
  (data->localData[0]->realVars[3] /* der(integralError) STATE_DER */) = ((tmp0 && tmp3)?(data->localData[0]->realVars[0] /* error STATE(1,derivativeError) */):0.0);
  TRACE_POP
}

OMC_DISABLE_OPT
int TankControlSystem_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_DAE);
#endif

  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  TankControlSystem_functionLocalKnownVars(data, threadData);
  TankControlSystem_eqFunction_14(data, threadData);

  TankControlSystem_eqFunction_21(data, threadData);

  TankControlSystem_eqFunction_22(data, threadData);

  TankControlSystem_eqFunction_23(data, threadData);

  TankControlSystem_eqFunction_24(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_DAE);
#endif
  TRACE_POP
  return 0;
}


int TankControlSystem_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/* forwarded equations */
extern void TankControlSystem_eqFunction_14(DATA* data, threadData_t *threadData);
extern void TankControlSystem_eqFunction_21(DATA* data, threadData_t *threadData);
extern void TankControlSystem_eqFunction_22(DATA* data, threadData_t *threadData);
extern void TankControlSystem_eqFunction_24(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  {
    TankControlSystem_eqFunction_14(data, threadData);
    threadData->lastEquationSolved = 14;
  }
  {
    TankControlSystem_eqFunction_21(data, threadData);
    threadData->lastEquationSolved = 21;
  }
  {
    TankControlSystem_eqFunction_22(data, threadData);
    threadData->lastEquationSolved = 22;
  }
  {
    TankControlSystem_eqFunction_24(data, threadData);
    threadData->lastEquationSolved = 24;
  }
}

int TankControlSystem_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_FUNCTION_ODE);
#endif

  
  data->simulationInfo->callStatistics.functionODE++;
  
  TankControlSystem_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_FUNCTION_ODE);
#endif

  TRACE_POP
  return 0;
}

/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "TankControlSystem_12jac.h"
#include "TankControlSystem_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks TankControlSystem_callback = {
   (int (*)(DATA *, threadData_t *, void *)) TankControlSystem_performSimulation,    /* performSimulation */
   (int (*)(DATA *, threadData_t *, void *)) TankControlSystem_performQSSSimulation,    /* performQSSSimulation */
   TankControlSystem_updateContinuousSystem,    /* updateContinuousSystem */
   TankControlSystem_callExternalObjectDestructors,    /* callExternalObjectDestructors */
   TankControlSystem_initialNonLinearSystem,    /* initialNonLinearSystem */
   NULL,    /* initialLinearSystem */
   NULL,    /* initialMixedSystem */
   #if !defined(OMC_NO_STATESELECTION)
   TankControlSystem_initializeStateSets,
   #else
   NULL,
   #endif    /* initializeStateSets */
   TankControlSystem_initializeDAEmodeData,
   TankControlSystem_functionODE,
   TankControlSystem_functionAlgebraics,
   TankControlSystem_functionDAE,
   TankControlSystem_functionLocalKnownVars,
   TankControlSystem_input_function,
   TankControlSystem_input_function_init,
   TankControlSystem_input_function_updateStartValues,
   TankControlSystem_data_function,
   TankControlSystem_output_function,
   TankControlSystem_setc_function,
   TankControlSystem_setb_function,
   TankControlSystem_function_storeDelayed,
   TankControlSystem_function_storeSpatialDistribution,
   TankControlSystem_function_initSpatialDistribution,
   TankControlSystem_updateBoundVariableAttributes,
   TankControlSystem_functionInitialEquations,
   1, /* useHomotopy - 0: local homotopy (equidistant lambda), 1: global homotopy (equidistant lambda), 2: new global homotopy approach (adaptive lambda), 3: new local homotopy approach (adaptive lambda)*/
   NULL,
   TankControlSystem_functionRemovedInitialEquations,
   TankControlSystem_updateBoundParameters,
   TankControlSystem_checkForAsserts,
   TankControlSystem_function_ZeroCrossingsEquations,
   TankControlSystem_function_ZeroCrossings,
   TankControlSystem_function_updateRelations,
   TankControlSystem_zeroCrossingDescription,
   TankControlSystem_relationDescription,
   TankControlSystem_function_initSample,
   TankControlSystem_INDEX_JAC_A,
   TankControlSystem_INDEX_JAC_B,
   TankControlSystem_INDEX_JAC_C,
   TankControlSystem_INDEX_JAC_D,
   TankControlSystem_INDEX_JAC_F,
   TankControlSystem_INDEX_JAC_H,
   TankControlSystem_initialAnalyticJacobianA,
   TankControlSystem_initialAnalyticJacobianB,
   TankControlSystem_initialAnalyticJacobianC,
   TankControlSystem_initialAnalyticJacobianD,
   TankControlSystem_initialAnalyticJacobianF,
   TankControlSystem_initialAnalyticJacobianH,
   TankControlSystem_functionJacA_column,
   TankControlSystem_functionJacB_column,
   TankControlSystem_functionJacC_column,
   TankControlSystem_functionJacD_column,
   TankControlSystem_functionJacF_column,
   TankControlSystem_functionJacH_column,
   TankControlSystem_linear_model_frame,
   TankControlSystem_linear_model_datarecovery_frame,
   TankControlSystem_mayer,
   TankControlSystem_lagrange,
   TankControlSystem_pickUpBoundsForInputsInOptimization,
   TankControlSystem_setInputData,
   TankControlSystem_getTimeGrid,
   TankControlSystem_symbolicInlineSystem,
   TankControlSystem_function_initSynchronous,
   TankControlSystem_function_updateSynchronous,
   TankControlSystem_function_equationsSynchronous,
   TankControlSystem_inputNames,
   TankControlSystem_dataReconciliationInputNames,
   TankControlSystem_dataReconciliationUnmeasuredVariables,
   NULL,
   NULL,
   NULL,
   NULL,
   -1,
   NULL,
   NULL,
   -1

};

#define _OMC_LIT_RESOURCE_0_name_data "TankControlSystem"
#define _OMC_LIT_RESOURCE_0_dir_data "C:/ktk/models"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_name,17,_OMC_LIT_RESOURCE_0_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir,13,_OMC_LIT_RESOURCE_0_dir_data);

static const MMC_DEFSTRUCTLIT(_OMC_LIT_RESOURCES,2,MMC_ARRAY_TAG) {MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir)}};
void TankControlSystem_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  threadData->localRoots[LOCAL_ROOT_SIMULATION_DATA] = data;
  data->callback = &TankControlSystem_callback;
  OpenModelica_updateUriMapping(threadData, MMC_REFSTRUCTLIT(_OMC_LIT_RESOURCES));
  data->modelData->modelName = "TankControlSystem";
  data->modelData->modelFilePrefix = "TankControlSystem";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/ktk/models";
  data->modelData->modelGUID = "{a38762a5-0d71-4b68-aaf0-82b6937be0aa}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "TankControlSystem_init.c"
    ;
  static const char contents_info[] =
    #include "TankControlSystem_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "TankControlSystem_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "TankControlSystem_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  data->modelData->modelDataXml.fileName = "TankControlSystem_info.json";
  data->modelData->resourcesDir = NULL;
  data->modelData->runTestsuite = 0;
  data->modelData->nStates = 2;
  data->modelData->nVariablesReal = 9;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 11;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 0;
  data->modelData->nAliasReal = 0;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  data->modelData->nZeroCrossings = 1;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 2;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 26;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 2;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 8;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  data->modelData->nDelayExpressions = 0;
  data->modelData->nBaseClocks = 0;
  data->modelData->nSpatialDistributions = 0;
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
  data->modelData->nSetcVars = 0;
  data->modelData->ndataReconVars = 0;
  data->modelData->nSetbVars = 0;
  data->modelData->nRelatedBoundaryConditions = 0;
  data->modelData->linearizationDumpLanguage = OMC_LINEARIZE_DUMP_LANGUAGE_MODELICA;
}

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}


#if defined(__MINGW32__) || defined(_MSC_VER)

#if !defined(_UNICODE)
#define _UNICODE
#endif
#if !defined(UNICODE)
#define UNICODE
#endif

#include <windows.h>
char** omc_fixWindowsArgv(int argc, wchar_t **wargv)
{
  char** newargv;
  /* Support for non-ASCII characters
  * Read the unicode command line arguments and translate it to char*
  */
  newargv = (char**)malloc(argc*sizeof(char*));
  for (int i = 0; i < argc; i++) {
    newargv[i] = omc_wchar_to_multibyte_str(wargv[i]);
  }
  return newargv;
}

#define OMC_MAIN wmain
#define OMC_CHAR wchar_t
#define OMC_EXPORT __declspec(dllexport) extern

#else
#define omc_fixWindowsArgv(N, A) (A)
#define OMC_MAIN main
#define OMC_CHAR char
#define OMC_EXPORT extern
#endif

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
#if defined(OMC_DLL_MAIN_DEFINE)
OMC_EXPORT int omcDllMain(int argc, OMC_CHAR **argv)
#else
int OMC_MAIN(int argc, OMC_CHAR** argv)
#endif
{
  char** newargv = omc_fixWindowsArgv(argc, argv);
  /*
    Set the error functions to be used for simulation.
    The default value for them is 'functions' version. Change it here to 'simulation' versions
  */
  omc_assert = omc_assert_simulation;
  omc_assert_withEquationIndexes = omc_assert_simulation_withEquationIndexes;

  omc_assert_warning_withEquationIndexes = omc_assert_warning_simulation_withEquationIndexes;
  omc_assert_warning = omc_assert_warning_simulation;
  omc_terminate = omc_terminate_simulation;
  omc_throw = omc_throw_simulation;

  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    TankControlSystem_setupDataStruc(&data, threadData);
    res = _main_initRuntimeAndSimulation(argc, newargv, &data, threadData);
    if(res == 0) {
      res = _main_SimulationRuntime(argc, newargv, &data, threadData);
    }
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  return res;
}

#ifdef __cplusplus
}
#endif


