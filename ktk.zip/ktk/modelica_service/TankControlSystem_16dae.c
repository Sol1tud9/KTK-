/* DAE residuals is empty */
 #include "TankControlSystem_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int TankControlSystem_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
