/* Initial State Set */
#include "TankControlSystem_model.h"
#include "TankControlSystem_11mix.h"
#include "TankControlSystem_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void TankControlSystem_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

