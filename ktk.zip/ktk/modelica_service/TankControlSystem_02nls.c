/* Non Linear Systems */
#include "TankControlSystem_model.h"
#include "TankControlSystem_12jac.h"
#include "simulation/jacobian_util.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* inner equations */

/*
equation index: 4
type: SIMPLE_ASSIGN
heaterPower = min(max(Kp * error + Ki * integralError + Kd * derivativeError, 0.0), heaterPowerMax)
*/
void TankControlSystem_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  (data->localData[0]->realVars[7] /* heaterPower variable */) = fmin(fmax(((data->simulationInfo->realParameter[2] /* Kp PARAM */)) * ((data->localData[0]->realVars[0] /* error STATE(1,derivativeError) */)) + ((data->simulationInfo->realParameter[1] /* Ki PARAM */)) * ((data->localData[0]->realVars[1] /* integralError STATE(1) */)) + ((data->simulationInfo->realParameter[0] /* Kd PARAM */)) * ((data->localData[0]->realVars[6] /* derivativeError variable */)),0.0),(data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */));
  TRACE_POP
}
/*
equation index: 5
type: SIMPLE_ASSIGN
$DER.temperature = (heaterPower + heatLossCoeff * (ambientTemperature - temperature)) / (tankVolume * density * heatCapacity)
*/
void TankControlSystem_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  (data->localData[0]->realVars[4] /* der(temperature) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[7] /* heaterPower variable */) + ((data->simulationInfo->realParameter[6] /* heatLossCoeff PARAM */)) * ((data->simulationInfo->realParameter[3] /* ambientTemperature PARAM */) - (data->localData[0]->realVars[8] /* temperature DUMMY_STATE */)),(((data->simulationInfo->realParameter[10] /* tankVolume PARAM */)) * ((data->simulationInfo->realParameter[4] /* density PARAM */))) * ((data->simulationInfo->realParameter[5] /* heatCapacity PARAM */)),"tankVolume * density * heatCapacity",equationIndexes);
  TRACE_POP
}

void residualFunc11(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,11};
  int i,j;
  /* iteration variables */
  for (i=0; i<1; i++) {
    if (isinf(xloc[i]) || isnan(xloc[i])) {
      errorStreamPrint(LOG_NLS, 0, "residualFunc11: Iteration variable `%s` is inf or nan.",
        modelInfoGetEquation(&data->modelData->modelDataXml, 11).vars[i]);
      for (j=0; j<1; j++) {
        res[j] = NAN;
      }
      throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, equationIndexes, "residualFunc11 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
      return;
    }
  }
  (data->localData[0]->realVars[6] /* derivativeError variable */) = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  TankControlSystem_eqFunction_4(data, threadData);

  /* local constraints */
  TankControlSystem_eqFunction_5(data, threadData);
  /* body */
  res[0] = (-(data->localData[0]->realVars[4] /* der(temperature) DUMMY_DER */)) - (data->localData[0]->realVars[6] /* derivativeError variable */);
  /* restore known outputs */
  TRACE_POP
}

OMC_DISABLE_OPT
void initializeSparsePatternNLS11(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = TRUE;
  inSysData->sparsePattern = allocSparsePattern(1, 1, 1);
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern->leadindex, colPtrIndex, (1+1)*sizeof(unsigned int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern->leadindex[i] += inSysData->sparsePattern->leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern->index, rowIndex, 1*sizeof(unsigned int));
  
  /* write color array */
  /* color 1 with 1 columns */
  const int indices_1[1] = {0};
  for(i=0; i<1; i++)
    inSysData->sparsePattern->colorCols[indices_1[i]] = 1;
}

void freeSparsePatternNLS11(NONLINEAR_SYSTEM_DATA* inSysData)
{
  if (inSysData->isPatternAvailable) {
    freeSparsePattern(inSysData->sparsePattern);
    free(inSysData->sparsePattern);
    inSysData->sparsePattern = NULL;
    inSysData->isPatternAvailable = FALSE;
  }
}
OMC_DISABLE_OPT
void initializeNonlinearPatternNLS11(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  inSysData->nonlinearPattern = (NONLINEAR_PATTERN*) malloc(sizeof(NONLINEAR_PATTERN));
  inSysData->nonlinearPattern->numberOfVars = 1;
  inSysData->nonlinearPattern->numberOfEqns = 1;
  inSysData->nonlinearPattern->numberOfNonlinear = 1;
  inSysData->nonlinearPattern->indexVar = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->indexEqn = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->columns = (unsigned int*) malloc(1*sizeof(unsigned int));
  inSysData->nonlinearPattern->rows = (unsigned int*) malloc(1*sizeof(unsigned int));
  /* initialize and accumulate index vectors */
  const int index_var[1+1] = {0,1};
  const int index_eqn[1+1] = {0,1};
  memcpy(inSysData->nonlinearPattern->indexVar, index_var, (1+1)*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->indexEqn, index_eqn, (1+1)*sizeof(unsigned int));
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexVar[i] += inSysData->nonlinearPattern->indexVar[i-1];
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexEqn[i] += inSysData->nonlinearPattern->indexEqn[i-1];
  /* initialize columns and rows */
  const int columns[1] = {0};
  const int rows[1] = {0};
  memcpy(inSysData->nonlinearPattern->columns, columns, 1*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->rows, rows, 1*sizeof(unsigned int));
}

OMC_DISABLE_OPT
void initializeStaticDataNLS11(DATA* data, threadData_t *threadData, NONLINEAR_SYSTEM_DATA *sysData, modelica_boolean initSparsePattern, modelica_boolean initNonlinearPattern)
{
  int i=0;
  /* static nls data for derivativeError */
  sysData->nominal[i] = data->modelData->realVarsData[6].attribute /* derivativeError */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[6].attribute /* derivativeError */.min;
  sysData->max[i++]   = data->modelData->realVarsData[6].attribute /* derivativeError */.max;
  /* initial sparse pattern */
  if (initSparsePattern) {
    initializeSparsePatternNLS11(sysData);
  }
  if (initNonlinearPattern) {
    initializeNonlinearPatternNLS11(sysData);
  }
}

OMC_DISABLE_OPT
void freeStaticDataNLS11(DATA* data, threadData_t *threadData, NONLINEAR_SYSTEM_DATA *sysData)
{
  freeSparsePatternNLS11(sysData);
}

OMC_DISABLE_OPT
void getIterationVarsNLS11(DATA* data, double *array)
{
  array[0] = (data->localData[0]->realVars[6] /* derivativeError variable */);
}


/* inner equations */

/*
equation index: 15
type: SIMPLE_ASSIGN
$cse2 = max(Kp * error + Ki * integralError + Kd * derivativeError, 0.0)
*/
void TankControlSystem_eqFunction_15(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,15};
  (data->localData[0]->realVars[5] /* $cse2 variable */) = fmax(((data->simulationInfo->realParameter[2] /* Kp PARAM */)) * ((data->localData[0]->realVars[0] /* error STATE(1,derivativeError) */)) + ((data->simulationInfo->realParameter[1] /* Ki PARAM */)) * ((data->localData[0]->realVars[1] /* integralError STATE(1) */)) + ((data->simulationInfo->realParameter[0] /* Kd PARAM */)) * ((data->localData[0]->realVars[6] /* derivativeError variable */)),0.0);
  TRACE_POP
}
/*
equation index: 16
type: SIMPLE_ASSIGN
heaterPower = min($cse2, heaterPowerMax)
*/
void TankControlSystem_eqFunction_16(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,16};
  (data->localData[0]->realVars[7] /* heaterPower variable */) = fmin((data->localData[0]->realVars[5] /* $cse2 variable */),(data->simulationInfo->realParameter[7] /* heaterPowerMax PARAM */));
  TRACE_POP
}

void residualFunc21(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,21};
  int i,j;
  /* iteration variables */
  for (i=0; i<1; i++) {
    if (isinf(xloc[i]) || isnan(xloc[i])) {
      errorStreamPrint(LOG_NLS, 0, "residualFunc21: Iteration variable `%s` is inf or nan.",
        modelInfoGetEquation(&data->modelData->modelDataXml, 21).vars[i]);
      for (j=0; j<1; j++) {
        res[j] = NAN;
      }
      throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, equationIndexes, "residualFunc21 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
      return;
    }
  }
  (data->localData[0]->realVars[6] /* derivativeError variable */) = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  TankControlSystem_eqFunction_15(data, threadData);

  /* local constraints */
  TankControlSystem_eqFunction_16(data, threadData);
  /* body */
  res[0] = (data->localData[0]->realVars[7] /* heaterPower variable */) + ((data->simulationInfo->realParameter[6] /* heatLossCoeff PARAM */)) * ((data->simulationInfo->realParameter[3] /* ambientTemperature PARAM */) - (data->localData[0]->realVars[8] /* temperature DUMMY_STATE */)) + ((data->localData[0]->realVars[6] /* derivativeError variable */)) * (((data->simulationInfo->realParameter[5] /* heatCapacity PARAM */)) * (((data->simulationInfo->realParameter[4] /* density PARAM */)) * ((data->simulationInfo->realParameter[10] /* tankVolume PARAM */))));
  /* restore known outputs */
  TRACE_POP
}

OMC_DISABLE_OPT
void initializeSparsePatternNLS21(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = TRUE;
  inSysData->sparsePattern = allocSparsePattern(1, 1, 1);
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern->leadindex, colPtrIndex, (1+1)*sizeof(unsigned int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern->leadindex[i] += inSysData->sparsePattern->leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern->index, rowIndex, 1*sizeof(unsigned int));
  
  /* write color array */
  /* color 1 with 1 columns */
  const int indices_1[1] = {0};
  for(i=0; i<1; i++)
    inSysData->sparsePattern->colorCols[indices_1[i]] = 1;
}

void freeSparsePatternNLS21(NONLINEAR_SYSTEM_DATA* inSysData)
{
  if (inSysData->isPatternAvailable) {
    freeSparsePattern(inSysData->sparsePattern);
    free(inSysData->sparsePattern);
    inSysData->sparsePattern = NULL;
    inSysData->isPatternAvailable = FALSE;
  }
}
OMC_DISABLE_OPT
void initializeNonlinearPatternNLS21(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  inSysData->nonlinearPattern = (NONLINEAR_PATTERN*) malloc(sizeof(NONLINEAR_PATTERN));
  inSysData->nonlinearPattern->numberOfVars = 1;
  inSysData->nonlinearPattern->numberOfEqns = 1;
  inSysData->nonlinearPattern->numberOfNonlinear = 1;
  inSysData->nonlinearPattern->indexVar = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->indexEqn = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->columns = (unsigned int*) malloc(1*sizeof(unsigned int));
  inSysData->nonlinearPattern->rows = (unsigned int*) malloc(1*sizeof(unsigned int));
  /* initialize and accumulate index vectors */
  const int index_var[1+1] = {0,1};
  const int index_eqn[1+1] = {0,1};
  memcpy(inSysData->nonlinearPattern->indexVar, index_var, (1+1)*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->indexEqn, index_eqn, (1+1)*sizeof(unsigned int));
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexVar[i] += inSysData->nonlinearPattern->indexVar[i-1];
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexEqn[i] += inSysData->nonlinearPattern->indexEqn[i-1];
  /* initialize columns and rows */
  const int columns[1] = {0};
  const int rows[1] = {0};
  memcpy(inSysData->nonlinearPattern->columns, columns, 1*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->rows, rows, 1*sizeof(unsigned int));
}

OMC_DISABLE_OPT
void initializeStaticDataNLS21(DATA* data, threadData_t *threadData, NONLINEAR_SYSTEM_DATA *sysData, modelica_boolean initSparsePattern, modelica_boolean initNonlinearPattern)
{
  int i=0;
  /* static nls data for derivativeError */
  sysData->nominal[i] = data->modelData->realVarsData[6].attribute /* derivativeError */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[6].attribute /* derivativeError */.min;
  sysData->max[i++]   = data->modelData->realVarsData[6].attribute /* derivativeError */.max;
  /* initial sparse pattern */
  if (initSparsePattern) {
    initializeSparsePatternNLS21(sysData);
  }
  if (initNonlinearPattern) {
    initializeNonlinearPatternNLS21(sysData);
  }
}

OMC_DISABLE_OPT
void freeStaticDataNLS21(DATA* data, threadData_t *threadData, NONLINEAR_SYSTEM_DATA *sysData)
{
  freeSparsePatternNLS21(sysData);
}

OMC_DISABLE_OPT
void getIterationVarsNLS21(DATA* data, double *array)
{
  array[0] = (data->localData[0]->realVars[6] /* derivativeError variable */);
}

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize non-linear systems */
void TankControlSystem_initialNonLinearSystem(int nNonLinearSystems, NONLINEAR_SYSTEM_DATA* nonLinearSystemData)
{
  
  nonLinearSystemData[1].equationIndex = 21;
  nonLinearSystemData[1].size = 1;
  nonLinearSystemData[1].homotopySupport = 0 /* false */;
  nonLinearSystemData[1].mixedSystem = 0 /* false */;
  nonLinearSystemData[1].residualFunc = residualFunc21;
  nonLinearSystemData[1].strictTearingFunctionCall = NULL;
  nonLinearSystemData[1].analyticalJacobianColumn = TankControlSystem_functionJacNLSJac1_column;
  nonLinearSystemData[1].initialAnalyticalJacobian = TankControlSystem_initialAnalyticJacobianNLSJac1;
  nonLinearSystemData[1].jacobianIndex = 1 /*jacInx*/;
  nonLinearSystemData[1].initializeStaticNLSData = initializeStaticDataNLS21;
  nonLinearSystemData[1].freeStaticNLSData = freeStaticDataNLS21;
  nonLinearSystemData[1].getIterationVars = getIterationVarsNLS21;
  nonLinearSystemData[1].checkConstraints = NULL;
  
  
  nonLinearSystemData[0].equationIndex = 11;
  nonLinearSystemData[0].size = 1;
  nonLinearSystemData[0].homotopySupport = 0 /* false */;
  nonLinearSystemData[0].mixedSystem = 0 /* false */;
  nonLinearSystemData[0].residualFunc = residualFunc11;
  nonLinearSystemData[0].strictTearingFunctionCall = NULL;
  nonLinearSystemData[0].analyticalJacobianColumn = TankControlSystem_functionJacNLSJac0_column;
  nonLinearSystemData[0].initialAnalyticalJacobian = TankControlSystem_initialAnalyticJacobianNLSJac0;
  nonLinearSystemData[0].jacobianIndex = 0 /*jacInx*/;
  nonLinearSystemData[0].initializeStaticNLSData = initializeStaticDataNLS11;
  nonLinearSystemData[0].freeStaticNLSData = freeStaticDataNLS11;
  nonLinearSystemData[0].getIterationVars = getIterationVarsNLS11;
  nonLinearSystemData[0].checkConstraints = NULL;
}

#if defined(__cplusplus)
}
#endif

