/* DAE residuals is empty */
 #include "TankLevelControl_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int TankLevelControl_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
